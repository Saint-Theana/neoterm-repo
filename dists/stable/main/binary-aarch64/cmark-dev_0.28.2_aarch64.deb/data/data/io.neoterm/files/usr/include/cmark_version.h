#ifndef CMARK_VERSION_H
#define CMARK_VERSION_H

#define CMARK_VERSION ((0 << 16) | (28 << 8)  | 2)
#define CMARK_VERSION_STRING "0.28.2"

#endif
