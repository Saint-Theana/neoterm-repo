// Android-specific fake libc.h for the files in this directory.
#include <stddef.h>
#define weak_alias(name1,name2)  // nothing here.
