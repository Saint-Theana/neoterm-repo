#define PHP_ICONV_H_PATH </data/data/io.neoterm/files/usr/include/iconv.h>
