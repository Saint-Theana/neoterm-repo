MSVC71
------

Discouraged.  Use the :variable:`MSVC_VERSION` variable instead.

``True`` when using Microsoft Visual C++ 7.1.

Set to ``true`` when the compiler is version 7.1 of Microsoft Visual C++.
