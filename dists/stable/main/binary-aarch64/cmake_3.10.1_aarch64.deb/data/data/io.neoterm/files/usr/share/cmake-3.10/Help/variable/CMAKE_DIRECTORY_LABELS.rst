CMAKE_DIRECTORY_LABELS
-----------------------

Specify labels for the current directory.

This is used to initialize the :prop_dir:`LABELS` directory property.
