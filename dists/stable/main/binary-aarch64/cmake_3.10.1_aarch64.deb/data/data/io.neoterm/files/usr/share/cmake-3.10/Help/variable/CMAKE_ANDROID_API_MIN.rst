CMAKE_ANDROID_API_MIN
---------------------

Default value for the :prop_tgt:`ANDROID_API_MIN` target property.
See that target property for additional information.
