CPACK_PERMANENT
---------------

Request that this file not be removed on uninstall.

The property is currently only supported by the WIX generator.
