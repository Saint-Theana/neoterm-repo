<PROJECT-NAME>_VERSION_MAJOR
----------------------------

First version number component of the :variable:`<PROJECT-NAME>_VERSION`
variable as set by the :command:`project` command.
