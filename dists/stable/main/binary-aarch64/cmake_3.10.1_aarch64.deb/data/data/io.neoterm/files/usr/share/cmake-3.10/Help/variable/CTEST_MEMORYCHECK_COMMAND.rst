CTEST_MEMORYCHECK_COMMAND
-------------------------

Specify the CTest ``MemoryCheckCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
