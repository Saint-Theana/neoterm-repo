CMAKE_SHARED_LINKER_FLAGS_<CONFIG>
----------------------------------

Flags to be used when linking a shared library.

Same as ``CMAKE_C_FLAGS_*`` but used by the linker when creating shared
libraries.
