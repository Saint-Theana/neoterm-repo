CMAKE_COMPILER_IS_GNUCC
-----------------------

True if the ``C`` compiler is GNU.
Use :variable:`CMAKE_C_COMPILER_ID <CMAKE_<LANG>_COMPILER_ID>` instead.
