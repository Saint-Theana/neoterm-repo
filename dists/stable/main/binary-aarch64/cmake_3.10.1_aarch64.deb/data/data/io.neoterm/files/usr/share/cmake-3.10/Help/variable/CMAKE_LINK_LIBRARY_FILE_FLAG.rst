CMAKE_LINK_LIBRARY_FILE_FLAG
----------------------------

Flag to be used to link a library specified by a path to its file.

The flag will be used before a library file path is given to the
linker.  This is needed only on very few platforms.
