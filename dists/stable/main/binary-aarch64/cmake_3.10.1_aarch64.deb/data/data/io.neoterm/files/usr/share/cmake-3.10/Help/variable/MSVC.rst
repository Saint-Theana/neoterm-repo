MSVC
----

``True`` when using Microsoft Visual C++.

Set to ``true`` when the compiler is some version of Microsoft Visual C++.

See also the :variable:`MSVC_VERSION` variable.
