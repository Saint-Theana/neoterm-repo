CTEST_CVS_CHECKOUT
------------------

Deprecated.  Use :variable:`CTEST_CHECKOUT_COMMAND` instead.
