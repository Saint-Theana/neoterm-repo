CMAKE_VISIBILITY_INLINES_HIDDEN
-------------------------------

Default value for the :prop_tgt:`VISIBILITY_INLINES_HIDDEN` target
property when a target is created.
