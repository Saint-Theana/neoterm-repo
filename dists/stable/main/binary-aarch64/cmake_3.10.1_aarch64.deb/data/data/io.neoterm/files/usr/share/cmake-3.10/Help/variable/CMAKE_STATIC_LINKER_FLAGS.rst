CMAKE_STATIC_LINKER_FLAGS
-------------------------

Linker flags to be used to create static libraries.

These flags will be used by the linker when creating a static library.
