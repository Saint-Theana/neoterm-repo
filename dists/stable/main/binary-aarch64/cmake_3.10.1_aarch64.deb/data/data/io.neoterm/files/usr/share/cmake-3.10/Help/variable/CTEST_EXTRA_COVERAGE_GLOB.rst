CTEST_EXTRA_COVERAGE_GLOB
-------------------------

A list of regular expressions which will be used to find files which should be
covered by the :command:`ctest_coverage` command.

.. include:: CTEST_CUSTOM_XXX.txt
