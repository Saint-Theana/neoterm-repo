#ifndef R_VERSION_H
#define R_VERSION_H 1
#define R2_VERSION_COMMIT 0
#define R2_VERSION "2.1.0"
#define R2_GITTAP "2.1.0"
#define R2_GITTIP "HEAD"
#define R2_BIRTH "2017-12-03__14:56:11"
#endif
