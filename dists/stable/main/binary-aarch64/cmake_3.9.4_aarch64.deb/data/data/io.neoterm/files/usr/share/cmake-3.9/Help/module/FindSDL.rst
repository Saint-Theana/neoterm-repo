.. cmake-module:: ../../Modules/FindSDL.cmake
