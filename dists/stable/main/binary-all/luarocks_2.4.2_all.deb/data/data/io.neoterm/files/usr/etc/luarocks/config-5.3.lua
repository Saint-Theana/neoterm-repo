rocks_trees = {
   { name = [[user]], root = home..[[/.luarocks]] },
   { name = [[system]], root = [[/data/data/io.neoterm/files/usr]] }
}
